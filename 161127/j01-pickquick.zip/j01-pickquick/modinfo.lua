name = "PickyPickyPicky"
description = "Makes most everything quick pick!"
author = "Afro1967"
version = "1.0"
forumthread = ""

api_version = 10

all_clients_require_mod = true
dst_compatible = true

icon_atlas = "PickyPickyPicky.xml"
icon = "PickyPickyPicky.tex"
